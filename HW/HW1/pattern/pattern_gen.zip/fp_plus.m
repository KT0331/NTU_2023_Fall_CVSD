clear all
clc
format long g

qd = quantizer('float','convergent',[16,5]);
qi = quantizer('fixed','nearest',[4,0]);

PAT_NUM = 40000;

i_inst = char('1000');
i_data_a_temp = zeros([PAT_NUM 1]);
i_data_b_temp = zeros([PAT_NUM 1]);
o_data_temp = zeros([PAT_NUM 1]);
i_inst_temp = zeros([PAT_NUM 1]);

for i=1:PAT_NUM
    i_data_a_temp(i) = half(randi([1 65504]) * rand());
    i_data_b_temp(i) = half(randi([1 65504]) * rand());
    
%生成i_data_a     
    looptime = randi([1 7]);
    for j=1:looptime
        sign = randi([1 2]) - 1;
        if sign==1
            i_data_a_temp(i) = i_data_a_temp(i) * rand() * (-1);
        else
            i_data_a_temp(i) = i_data_a_temp(i) * rand();
        end
    end
    if i_data_a_temp(i) < (-0.00006104)
        i_data_a_temp(i) = i_data_a_temp(i) + 0.00006104;
    end
%     i_data_a_temp(i) = bin2num(qd,num2bin(qd,i_data_a_temp(i)));
 
%生成i_data_b
    looptime = randi([1 7]);
    for k=1:looptime
        sign = randi([1 2]) - 1;
        if sign==1
            i_data_b_temp(i) = i_data_b_temp(i) * rand() * (-1);
        else
            i_data_b_temp(i) = i_data_b_temp(i) * rand();
        end
    end
    if i_data_b_temp(i) < (-0.00006104)
        i_data_b_temp(i) = i_data_b_temp(i) + 0.00006104;
    end
%     i_data_b_temp(i) = bin2num(qd,num2bin(qd,i_data_b_temp(i)));
    
    o_data_temp(i) = half(i_data_a_temp(i)) + half(i_data_b_temp(i));
%   o_data_temp(i) = half(i_data_a_temp(i)) + half(i_data_b_temp(i));
    o_data_temp(i) = half(o_data_temp(i));
end

i_data_a = num2bin(qd,i_data_a_temp,PAT_NUM);
i_data_b = num2bin(qd,i_data_b_temp,PAT_NUM);
o_data = num2bin(qd,o_data_temp,PAT_NUM);

for i=1:PAT_NUM
    INST8p_I(i,[1:36])=strcat(i_inst([1:4]), i_data_a(i,[1:16]), i_data_b(i,[1:16]));
    INST8p_O=o_data;
end

for i=1:PAT_NUM
    fp1_e = bin2dec(i_data_a(i,[2:6]));
    fp2_e = bin2dec(i_data_b(i,[2:6]));
    fpo_e = bin2dec(o_data(i,[2:6]));
    if ((abs(fp1_e - fp2_e) > 11) | (fpo_e == 31))
        INST8p_I(i,[1:36]) = char('000000000000000000000000000000000000');
        INST8p_O(i,[1:16]) = char('0000000000000000');
    end
end

filename = 'fp_plus.xlsx';
writematrix(INST8p_I,filename,'Sheet',1,'Range','A1:A40000')
writematrix(INST8p_O,filename,'Sheet',1,'Range','B1:B40000')

char('ok')
