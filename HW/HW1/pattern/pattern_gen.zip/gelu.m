clear all
clc

format long;

PAT_NUM = 20000;

qd = quantizer('fixed','nearest',[16,10]);
qi = quantizer('fixed','nearest',[4,0]);

sign=0;

i_inst = num2bin(qi,4,PAT_NUM);
i_data_a_temp = zeros([PAT_NUM 1]);
i_data_b_temp = 0;
tanhx = zeros([PAT_NUM 1]);
tanh = zeros([PAT_NUM 1]);
o_data_temp = zeros([PAT_NUM 1]);

for i=1:PAT_NUM
    sign = randi([1 2]) - 1;
    if sign==1
        i_data_a_temp(i) = fi((randi([1 31]) * rand() * (-1)),1,16,10);
    else
        i_data_a_temp(i) = fi((randi([1 31]) * rand()),1,16,10);
    end
    tanhx(i) = 0.7978515625 * i_data_a_temp(i) * (1 + 0.044921875 * i_data_a_temp(i) * i_data_a_temp(i));
    tanhx(i) = fi(tanhx(i),1,16,10);
    if tanhx(i) <= -1.5
        tanh(i) = -1;
    elseif (tanhx(i) > -1.5) && (tanhx(i) < -0.5)
        tanh(i) = -0.25 + 0.5 * tanhx(i);
    elseif (tanhx(i) >= -0.5) && (tanhx(i) < 0.5)
        tanh(i) = tanhx(i);
    elseif (tanhx(i) >= 0.5) && (tanhx(i) < 1.5)
        tanh(i) = 0.25 + 0.5 * tanhx(i);  
    else
        tanh(i) = 1;
    end
    tanh(i) = fi(tanh(i),1,16,10);
    o_data_temp(i) = 0.5 * i_data_a_temp(i) * (1 + tanh(i));
end

i_data_a = num2bin(qd,i_data_a_temp,PAT_NUM);
i_data_b = num2bin(qd,i_data_b_temp,PAT_NUM);
o_data = num2bin(qd,o_data_temp,PAT_NUM);

for i=1:PAT_NUM
    INST11_I(i,[1:36])=strcat(i_inst([1:4]), i_data_a(i,[1:16]), i_data_b([1:16]));
    INST11_O=o_data;
end

filename = 'gelu.xlsx';
writematrix(INST11_I,filename,'Sheet',1,'Range','A1:A20000')
writematrix(INST11_O,filename,'Sheet',1,'Range','B1:B20000')