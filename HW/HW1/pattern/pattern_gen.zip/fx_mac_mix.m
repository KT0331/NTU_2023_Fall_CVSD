clear all
clc

format long;

fxmax = 31.9990234375;
fxmin = -31.9990234375;
PAT_NUM = 20000;

qd = quantizer('fixed','nearest',[16,10]);
qi = quantizer('fixed','nearest',[4,0]);

i_data_a_temp = zeros([PAT_NUM 1]);
i_data_b_temp = zeros([PAT_NUM 1]);
o_data_temp = zeros([PAT_NUM 1]);
i_inst_temp = zeros([PAT_NUM 1]);

for i=1:PAT_NUM
    sign = randi([1 2]) - 1;
    if sign==1
        i_data_a_temp(i) = fi((randi([1 31]) * rand() * (-1)),1,16,10);
    else
        i_data_a_temp(i) = fi((randi([1 31]) * rand()),1,16,10);
    end
    sign = randi([1 2]) - 1;
    if sign==1
        i_data_b_temp(i) = fi(randi([1 31]) * rand() * (-1),1,16,10);
    else
        i_data_b_temp(i) = fi(randi([1 31]) * rand(),1,16,10);
    end
%     i_data_a_temp(i) = fi((randi([1 31]) * rand()),1,16,10);
%     i_data_b_temp(i) = fi(randi([1 31]) * rand(),1,16,10);
    if i>=2
        i_inst_temp(i) = randi([1 4]) - 1;
    else
        i_inst_temp(i) = randi([1 3]) - 1;
    end
    if i_inst_temp(i) == 0 
        o_data_temp(i) = i_data_a_temp(i) + i_data_b_temp(i);
    elseif i_inst_temp(i) == 1
        o_data_temp(i) = i_data_a_temp(i) - i_data_b_temp(i);
    elseif i_inst_temp(i) == 2
        o_data_temp(i) = i_data_a_temp(i) * i_data_b_temp(i);
    else
        o_data_temp(i) = i_data_a_temp(i) * i_data_b_temp(i) + o_data_temp(i-1);
    end
    o_data_temp(i) = fi(o_data_temp(i),1,16,10);
end

i_inst = num2bin(qi,i_inst_temp,PAT_NUM);
i_data_a = num2bin(qd,i_data_a_temp,PAT_NUM);
i_data_b = num2bin(qd,i_data_b_temp,PAT_NUM);
o_data = num2bin(qd,o_data_temp,PAT_NUM);

for i=1:PAT_NUM
    INST10_I(i,[1:36])=strcat(i_inst(i,[1:4]), i_data_a(i,[1:16]), i_data_b(i,[1:16]));
    INST10_O=o_data;
end

filename = 'fx_mix.xlsx';
writematrix(INST10_I,filename,'Sheet',1,'Range','A1:A20000')
writematrix(INST10_O,filename,'Sheet',1,'Range','B1:B20000')

char('ok')



